package Data_Split;

public class Notification_Observation_Event {
    long id_event;
    long id_user;
    long geo;
    long device_type;
    public Notification_Observation_Event(long id_event, long id_user, long geo, long device_type){
        this.id_event=id_event;
        this.id_user=id_user;
        this.geo=geo;
        this.device_type=device_type;


    }


    void Envoyer(){

    }
}
