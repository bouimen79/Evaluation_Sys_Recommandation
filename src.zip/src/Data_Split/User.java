package Data_Split;

public class User {
	long id_user;
    public User(long id_user){
        this.id_user=id_user;
        
    }
}
